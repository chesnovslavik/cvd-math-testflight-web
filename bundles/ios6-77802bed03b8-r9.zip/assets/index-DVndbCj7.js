import{aR as r}from"./index-BWf2lCrl.js";var o=r();export{o as r};
