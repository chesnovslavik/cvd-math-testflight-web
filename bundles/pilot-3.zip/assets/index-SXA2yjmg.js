import{aJ as r}from"./index-DCavV_1k.js";var o=r();export{o as r};
