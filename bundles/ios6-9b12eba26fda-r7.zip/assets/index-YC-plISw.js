import{aQ as r}from"./index-1UKoFBzA.js";var o=r();export{o as r};
