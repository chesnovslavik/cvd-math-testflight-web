const n=[.3,.5,.65,.8,.92];function o(r){if(!Number.isInteger(r)||r<1||r>5)throw new Error("Неизвестный уровень бота.");return n[r-1]}function u(r,t){return t()<o(r)}export{u};
