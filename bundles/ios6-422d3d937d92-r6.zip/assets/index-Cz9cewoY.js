import{aP as r}from"./index-CtW31iAw.js";var o=r();export{o as r};
