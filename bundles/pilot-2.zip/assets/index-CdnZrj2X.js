import{aJ as r}from"./index-C7b2p8mA.js";var o=r();export{o as r};
