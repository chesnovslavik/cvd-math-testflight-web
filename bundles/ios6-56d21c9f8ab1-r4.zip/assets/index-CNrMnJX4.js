import{aJ as r}from"./index-CcFyir9g.js";var o=r();export{o as r};
