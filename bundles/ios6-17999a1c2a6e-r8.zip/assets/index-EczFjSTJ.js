import{aQ as r}from"./index-CTpjR5G6.js";var o=r();export{o as r};
