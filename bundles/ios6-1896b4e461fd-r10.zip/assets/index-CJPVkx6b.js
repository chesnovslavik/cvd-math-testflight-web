import{aR as r}from"./index-5JXZhSrf.js";var o=r();export{o as r};
